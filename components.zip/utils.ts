export const timeToSeconds = (timeStr: string): number => {
  if (!timeStr) return 0;
  const [minutes, rest] = timeStr.split(':');
  const [seconds, ms] = rest.split('.');
  return parseInt(minutes) * 60 + parseInt(seconds) + parseInt(ms) / 100;
};

export const secondsToTime = (totalSeconds: number): string => {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const ms = Math.round((totalSeconds - Math.floor(totalSeconds)) * 100);
  
  const pad = (num: number) => num.toString().padStart(2, '0');
  return `${pad(minutes)}:${pad(seconds)}.${pad(ms)}`;
};

export const formatDuration = (val: number) => `${val}`;

// Default Initial Data
export const INITIAL_JSON_DATA = `[
    {
        "time": "00:01.34",
        "type": "prelude"
    },
    {
        "time": "00:07.83",
        "text": [
            { "phrase": "何", "duration": 50 },
            { "phrase": "かに", "duration": 50 },
            { "phrase": "なり", "duration": 50 },
            { "phrase": "たくて ", "duration": 50 },
            { "phrase": "独", "duration": 50 },
            { "phrase": "り ", "duration": 50 },
            { "phrase": "部屋", "duration": 50 },
            { "phrase": "もが", "duration": 40 },
            { "phrase": "いて", "duration": 40 },
            { "phrase": "いた", "duration": 40 }
        ],
        "translation": "想要成為某些事物　獨自在房間裡掙扎著"
    },
    {
        "time": "00:13.00",
        "text": [
            { "phrase": "弱", "duration": 40 },
            { "phrase": "い", "duration": 30 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "見", "duration": 50 },
            { "phrase": "ないで", "duration": 40 }
        ],
        "translation": "請別看著這樣軟弱的我"
    },
    {
        "time": "00:17.85",
        "text": [
            { "phrase": "軋轢", "duration": 70 },
            { "phrase": "フルテンで", "duration": 140 },
            {
                "phrase": "現在",
                "duration": 40,
                "pronounciation": "いま",
                "pncat_forced": true
            },
            { "phrase": "から", "duration": 40 },
            { "phrase": "離", "duration": 40 },
            { "phrase": "れたく", "duration": 40 },
            { "phrase": "なった", "duration": 40 }
        ],
        "translation": "曾想遠離充滿紛爭和混亂的現狀"
    },
    {
        "time": "00:22.55",
        "text": [
            { "phrase": "見", "duration": 50 },
            { "phrase": "えない", "duration": 50 },
            { "phrase": "所", "duration": 50 },
            { "phrase": "に", "duration": 50 },
            { "phrase": "傷", "duration": 50 }
        ],
        "translation": "無人知曉的受傷"
    },
    {
        "time": "00:28.17",
        "text": [
            { "phrase": "悲", "duration": 50 },
            { "phrase": "しく", "duration": 50 },
            { "phrase": "なるよ ", "duration": 80 },
            { "phrase": "", "duration": 40 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "も", "duration": 50 },
            { "phrase": "", "duration": 90 },
            { "phrase": "本音", "duration": 50 },
            { "phrase": "と", "duration": 50 },
            { "phrase": "建前", "duration": 120 },
            { "phrase": "違", "duration": 50 },
            { "phrase": "う", "duration": 50 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "仍困在悲傷之中　至今依舊說不真心的話語"
    },
    {
        "time": "00:38.12",
        "text": [
            { "phrase": "僕", "duration": 50 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "僕", "duration": 70 },
            { "phrase": "のまま", "duration": 80 },
            { "phrase": "でいい?", "duration": 50 }
        ],
        "translation": "我只要做我自己就好嗎？"
    },
    {
        "time": "00:42.76",
        "text": [
            { "phrase": "明日", "duration": 50 },
            { "phrase": "を", "duration": 40 },
            { "phrase": "睨", "duration": 50 },
            { "phrase": "んだ", "duration": 40 },
            { "phrase": "まま", "duration": 50 }
        ],
        "translation": "這般地望著明日"
    },
    {
        "time": "00:46.59",
        "text": [
            { "phrase": "今", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "スピード", "duration": 50 },
            { "phrase": "じゃ", "duration": 50 },
            { "phrase": "追", "duration": 50 },
            { "phrase": "い", "duration": 50 },
            { "phrase": "越", "duration": 40 },
            { "phrase": "せない", "duration": 50 },
            { "phrase": "から", "duration": 40 }
        ],
        "translation": "因為如今的速度是追不上的"
    },
    {
        "time": "00:51.56",
        "text": [
            {
                "phrase": "最高到達点",
                "duration": 70,
                "pronounciation": "トップスピード",
                "pncat_forced": true
            },
            { "phrase": "超", "duration": 80 },
            { "phrase": "えて ", "duration": 50 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "君", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "元", "duration": 50 },
            { "phrase": "へ", "duration": 50 }
        ],
        "translation": "我會突破最高速限　奔往你的身旁"
    },
    {
        "time": "00:57.16",
        "text": [
            { "phrase": "不安", "duration": 50 },
            { "phrase": "なんて", "duration": 50 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "が", "duration": 50 },
            { "phrase": "吹", "duration": 50 },
            { "phrase": "き", "duration": 40 },
            { "phrase": "飛", "duration": 40 },
            { "phrase": "ばす", "duration": 50 },
            { "phrase": "よ", "duration": 50 }
        ],
        "translation": "將你些許的不安盡數吹散"
    },
    {
        "time": "01:02.12",
        "text": [
            { "phrase": "それで", "duration": 50 },
            { "phrase": "いい", "duration": 50 },
            { "phrase": "かい?", "duration": 50 },
            { "phrase": " ", "duration": 80 },
            { "phrase": "それで", "duration": 50 },
            { "phrase": "いい", "duration": 50 },
            { "phrase": "かい?", "duration": 50 }
        ],
        "translation": "只要這樣做就好嗎？這樣就可以了嗎？"
    },
    {
        "time": "01:06.43",
        "text": [
            { "phrase": "今", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "スピード", "duration": 50 },
            { "phrase": "じゃ", "duration": 50 },
            { "phrase": "頼", "duration": 70 },
            { "phrase": "り", "duration": 50 },
            { "phrase": "ない", "duration": 80 },
            { "phrase": "けど", "duration": 50 }
        ],
        "translation": "即便現在的速度還不夠可靠"
    },
    {
        "time": "01:11.43",
        "text": [
            {
                "phrase": "最高到達点",
                "duration": 50,
                "pronounciation": "トップスピード",
                "pncat_forced": true
            },
            { "phrase": "超", "duration": 80 },
            { "phrase": "えて", "duration": 50 },
            { "phrase": " ", "duration": 50 },
            { "phrase": "君", "duration": 50 },
            { "phrase": "だけは", "duration": 50 },
            { "phrase": "守", "duration": 70 },
            { "phrase": "るよ", "duration": 70 }
        ],
        "translation": "我會超越自身極限　只為守護好你"
    },
    {
        "time": "01:16.98",
        "text": [
            { "phrase": "不安", "duration": 50 },
            { "phrase": "なんて", "duration": 70 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "が", "duration": 50 },
            { "phrase": "消", "duration": 40 },
            { "phrase": "し", "duration": 40 },
            { "phrase": "去", "duration": 40 },
            { "phrase": "る", "duration": 40 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "將你些許的不安盡數吹散"
    },
    {
        "time": "01:21.95",
        "text": [
            { "phrase": "君", "duration": 30 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "ずっと", "duration": 30 },
            { "phrase": "前", "duration": 30 },
            { "phrase": "だけ", "duration": 30 },
            { "phrase": "向", "duration": 30 },
            { "phrase": "いてて", "duration": 40 },
            { "phrase": "って", "duration": 30 }
        ],
        "translation": "你只要一直看著前方就好"
    },
    {
        "time": "01:25.10",
        "text": [
            { "phrase": "絶", "duration": 30 },
            { "phrase": "やさ", "duration": 30 },
            { "phrase": "ないで", "duration": 30 },
            { "phrase": "笑顔", "duration": 30 },
            { "phrase": "だけ", "duration": 50 },
            { "phrase": "は", "duration": 30 }
        ],
        "translation": "唯獨不會讓那笑容消失"
    },
    {
        "time": "01:27.57",
        "text": [
            { "phrase": "嘘", "duration": 40 },
            { "phrase": "じゃ", "duration": 40 },
            { "phrase": "ないと", "duration": 30 },
            { "phrase": "誓", "duration": 50 },
            { "phrase": "うから", "duration": 50 }
        ],
        "translation": "帶著真心立下誓言"
    },
    {
        "time": "01:32.45",
        "text": [
            { "phrase": "何", "duration": 50 },
            { "phrase": "かに", "duration": 50 },
            { "phrase": "なり", "duration": 50 },
            { "phrase": "たくて ", "duration": 50 },
            { "phrase": "また", "duration": 50 },
            { "phrase": "独", "duration": 50 },
            { "phrase": "り", "duration": 50 },
            { "phrase": "もが", "duration": 40 },
            { "phrase": "いて", "duration": 30 },
            { "phrase": "いた", "duration": 30 }
        ],
        "translation": "想要成為某些事物　再次獨自掙扎著"
    },
    {
        "time": "01:37.60",
        "text": [
            { "phrase": "僕", "duration": 50 },
            { "phrase": "に", "duration": 50 },
            { "phrase": "何", "duration": 40 },
            { "phrase": "が", "duration": 40 },
            { "phrase": "出来", "duration": 50 },
            { "phrase": "るんだ", "duration": 50 }
        ],
        "translation": "究竟能成就些什麼"
    },
    {
        "time": "01:42.39",
        "text": [
            { "phrase": "卑屈", "duration": 50 },
            { "phrase": "な", "duration": 50 },
            { "phrase": "思考", "duration": 50 },
            { "phrase": "の", "duration": 30 },
            { "phrase": "果", "duration": 20 },
            { "phrase": "て ", "duration": 20 },
            { "phrase": "認", "duration": 20 },
            { "phrase": "めて", "duration": 20 },
            { "phrase": "欲", "duration": 20 },
            { "phrase": "しい", "duration": 40 },
            { "phrase": "だけ", "duration": 20 },
            { "phrase": "だった", "duration": 40 }
        ],
        "translation": "自卑的念頭到最後　只是想要被認可而已"
    },
    {
        "time": "01:47.07",
        "text": [
            { "phrase": "癒", "duration": 50 },
            { "phrase": "えない", "duration": 50 },
            { "phrase": "心傷", "duration": 120 }
        ],
        "translation": "內心無法癒合的傷"
    },
    {
        "time": "01:52.75",
        "text": [
            { "phrase": "悲", "duration": 50 },
            { "phrase": "しく", "duration": 50 },
            { "phrase": "なるよ ", "duration": 120 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "も", "duration": 50 },
            { "phrase": "", "duration": 80 },
            { "phrase": "涙", "duration": 50 },
            { "phrase": "だけが", "duration": 120 },
            { "phrase": "邪魔", "duration": 100 },
            { "phrase": "をする", "duration": 100 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "仍困在悲傷之中　因為現在只有淚水在困擾我"
    },
    {
        "time": "02:02.54",
        "text": [
            { "phrase": "僕", "duration": 50 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "僕", "duration": 70 },
            { "phrase": "のまま", "duration": 80 },
            { "phrase": "でいい", "duration": 50 }
        ],
        "translation": "我會做著我自己就好"
    },
    {
        "time": "02:07.42",
        "text": [
            { "phrase": "明日", "duration": 50 },
            { "phrase": "を", "duration": 50 },
            { "phrase": "睨", "duration": 50 },
            { "phrase": "んだ", "duration": 50 },
            { "phrase": "まま", "duration": 50 }
        ],
        "translation": "這般地望著明日"
    },
    {
        "time": "02:11.18",
        "text": [
            { "phrase": "今", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "スピード", "duration": 50 },
            { "phrase": "じゃ", "duration": 50 },
            { "phrase": "追", "duration": 50 },
            { "phrase": "い", "duration": 50 },
            { "phrase": "越", "duration": 50 },
            { "phrase": "せない", "duration": 50 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "因為如今的速度是追不上的"
    },
    {
        "time": "02:16.12",
        "text": [
            {
                "phrase": "最高到達点",
                "duration": 70,
                "pronounciation": "トップスピード",
                "pncat_forced": true
            },
            { "phrase": "超", "duration": 70 },
            { "phrase": "えて ", "duration": 50 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "君", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "", "duration": 30 },
            { "phrase": "元", "duration": 50 },
            { "phrase": "へ", "duration": 50 }
        ],
        "translation": "我會突破最高速限　奔往你的身旁"
    },
    {
        "time": "02:21.56",
        "text": [
            { "phrase": "不安、", "duration": 50 },
            { "phrase": "焦燥", "duration": 50 },
            { "phrase": "は", "duration": 50 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "に", "duration": 50 },
            { "phrase": "預", "duration": 50 },
            { "phrase": "ければ", "duration": 70 },
            { "phrase": "いい", "duration": 50 }
        ],
        "translation": "不安與焦躁都交給我來就好"
    },
    {
        "time": "02:26.57",
        "text": [
            { "phrase": "それで", "duration": 50 },
            { "phrase": "いい", "duration": 50 },
            { "phrase": "かい?", "duration": 50 },
            { "phrase": " ", "duration": 70 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "どう", "duration": 50 },
            { "phrase": "だい?", "duration": 70 }
        ],
        "translation": "這樣就可以了吧？我這樣還可以吧？"
    },
    {
        "time": "02:31.42",
        "text": [
            { "phrase": "弱気", "duration": 20 },
            { "phrase": "な", "duration": 20 },
            { "phrase": "奴", "duration": 20 },
            { "phrase": "の", "duration": 20 },
            { "phrase": "", "duration": 20 },
            { "phrase": "守", "duration": 40 },
            { "phrase": "るだ", "duration": 30 },
            { "phrase": "なんて", "duration": 20 }
        ],
        "translation": "保護弱小　這樣的話"
    },
    {
        "time": "02:34.04",
        "text": [
            { "phrase": "響", "duration": 20 },
            { "phrase": "か", "duration": 20 },
            { "phrase": "ない", "duration": 20 },
            { "phrase": "よな ", "duration": 20 },
            { "phrase": "わか", "duration": 20 },
            { "phrase": "ってる", "duration": 50 },
            { "phrase": " ", "duration": 50 },
            { "phrase": "わか", "duration": 20 },
            { "phrase": "って", "duration": 50 },
            { "phrase": "いても", "duration": 60 }
        ],
        "translation": "是無法打動人心的　我是知道的　即便心知肚明也"
    },
    {
        "time": "02:46.40",
        "text": [
            { "phrase": "泥臭", "duration": 50 },
            { "phrase": "くて", "duration": 20 },
            { "phrase": "いい、", "duration": 20 },
            { "phrase": "笑", "duration": 40 },
            { "phrase": "われ", "duration": 20 },
            { "phrase": "ても", "duration": 20 },
            { "phrase": "いい", "duration": 20 },
            { "phrase": " ", "duration": 50 },
            { "phrase": "聞", "duration": 20 },
            { "phrase": "かせた", "duration": 20 },
            { "phrase": "芯", "duration": 80 },
            { "phrase": "の", "duration": 30 },
            { "phrase": "臓", "duration": 50 }
        ],
        "translation": "就算很老土、就算會被嘲笑　我也想傳達內心的鼓動"
    },
    {
        "time": "02:52.19",
        "text": [
            { "phrase": "今", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "スピード", "duration": 50 },
            { "phrase": "じゃ", "duration": 50 },
            { "phrase": "追", "duration": 50 },
            { "phrase": "い", "duration": 50 },
            { "phrase": "越", "duration": 50 },
            { "phrase": "せない", "duration": 50 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "因為如今的速度是追不上的"
    },
    {
        "time": "02:57.06",
        "text": [
            {
                "phrase": "最高到達点",
                "duration": 80,
                "pronounciation": "トップスピード",
                "pncat_forced": true
            },
            { "phrase": "超", "duration": 50 },
            { "phrase": "えて ", "duration": 50 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "君", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "", "duration": 50 },
            { "phrase": "元", "duration": 50 },
            { "phrase": "へ", "duration": 50 }
        ],
        "translation": "我會突破最高速限　奔往你的身旁"
    },
    {
        "time": "03:02.64",
        "text": [
            { "phrase": "不安", "duration": 50 },
            { "phrase": "なんて", "duration": 50 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "が", "duration": 50 },
            { "phrase": "吹", "duration": 50 },
            { "phrase": "き", "duration": 50 },
            { "phrase": "飛", "duration": 50 },
            { "phrase": "ばす", "duration": 50 },
            { "phrase": "よ", "duration": 50 }
        ],
        "translation": "將你些許的不安盡數吹散"
    },
    {
        "time": "03:07.66",
        "text": [
            { "phrase": "それで", "duration": 50 },
            { "phrase": "いい", "duration": 50 },
            { "phrase": "かい?", "duration": 50 },
            { "phrase": " ", "duration": 80 },
            { "phrase": "それで", "duration": 50 },
            { "phrase": "いい", "duration": 50 },
            { "phrase": "かい?", "duration": 50 }
        ],
        "translation": "只要這樣做就好嗎？這樣就可以了嗎？"
    },
    {
        "time": "03:12.02",
        "text": [
            { "phrase": "今", "duration": 50 },
            { "phrase": "の", "duration": 50 },
            { "phrase": "スピード", "duration": 50 },
            { "phrase": "じゃ", "duration": 50 },
            { "phrase": "頼", "duration": 70 },
            { "phrase": "り", "duration": 50 },
            { "phrase": "ない", "duration": 80 },
            { "phrase": "けど", "duration": 50 }
        ],
        "translation": "即便現在的速度還不值得信賴"
    },
    {
        "time": "03:16.91",
        "text": [
            {
                "phrase": "最高到達点",
                "duration": 90,
                "pronounciation": "トップスピード",
                "pncat_forced": true
            },
            { "phrase": "超", "duration": 50 },
            { "phrase": "えて", "duration": 50 },
            { "phrase": " ", "duration": 50 },
            { "phrase": "今", "duration": 50 },
            { "phrase": "君", "duration": 50 },
            { "phrase": "を", "duration": 50 },
            { "phrase": "救", "duration": 50 },
            { "phrase": "うよ", "duration": 50 }
        ],
        "translation": "我會超越自身極限　立刻拯救你"
    },
    {
        "time": "03:22.47",
        "text": [
            { "phrase": "不安", "duration": 50 },
            { "phrase": "なんて", "duration": 90 },
            { "phrase": "僕", "duration": 50 },
            { "phrase": "が", "duration": 50 },
            { "phrase": "消", "duration": 40 },
            { "phrase": "し", "duration": 40 },
            { "phrase": "去", "duration": 20 },
            { "phrase": "る", "duration": 40 },
            { "phrase": "から", "duration": 50 }
        ],
        "translation": "將你些許的不安盡數消去"
    },
    {
        "time": "03:27.54",
        "text": [
            { "phrase": "君", "duration": 30 },
            { "phrase": "は", "duration": 30 },
            { "phrase": "ずっと", "duration": 30 },
            { "phrase": "前", "duration": 30 },
            { "phrase": "だけ", "duration": 30 },
            { "phrase": "向", "duration": 30 },
            { "phrase": "いてて", "duration": 40 },
            { "phrase": "って", "duration": 30 }
        ],
        "translation": "你只要一直看著前方就好"
    },
    {
        "time": "03:30.61",
        "text": [
            { "phrase": "流", "duration": 30 },
            { "phrase": "さ", "duration": 30 },
            { "phrase": "ないで", "duration": 40 },
            { "phrase": "雫", "duration": 40 },
            { "phrase": "だけ", "duration": 40 },
            { "phrase": "は", "duration": 30 }
        ],
        "translation": "唯獨不會讓那淚珠落下"
    },
    {
        "time": "03:33.14",
        "text": [
            { "phrase": "嘘", "duration": 40 },
            { "phrase": "じゃ", "duration": 40 },
            { "phrase": "ないと", "duration": 30 },
            { "phrase": "誓", "duration": 50 },
            { "phrase": "うから", "duration": 50 }
        ],
        "translation": "帶著真心立下誓言"
    },
    {
        "time": "03:35.75",
        "type": "end"
    }
]`;